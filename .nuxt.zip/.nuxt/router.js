import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _13913d46 = () => interopDefault(import('..\\pages\\blog.vue' /* webpackChunkName: "pages_blog" */))
const _4409ce12 = () => interopDefault(import('..\\pages\\create.vue' /* webpackChunkName: "pages_create" */))
const _c1c0664e = () => interopDefault(import('..\\pages\\exit.vue' /* webpackChunkName: "pages_exit" */))
const _32a1a9be = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _6f2dadb0 = () => interopDefault(import('..\\pages\\otheruser.vue' /* webpackChunkName: "pages_otheruser" */))
const _6d8da344 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages_register" */))
const _7db30b62 = () => interopDefault(import('..\\pages\\updatearticle.vue' /* webpackChunkName: "pages_updatearticle" */))
const _0dc3e106 = () => interopDefault(import('..\\pages\\user.vue' /* webpackChunkName: "pages_user" */))
const _68fa06a7 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/blog",
    component: _13913d46,
    name: "blog"
  }, {
    path: "/create",
    component: _4409ce12,
    name: "create"
  }, {
    path: "/exit",
    component: _c1c0664e,
    name: "exit"
  }, {
    path: "/login",
    component: _32a1a9be,
    name: "login"
  }, {
    path: "/otheruser",
    component: _6f2dadb0,
    name: "otheruser"
  }, {
    path: "/register",
    component: _6d8da344,
    name: "register"
  }, {
    path: "/updatearticle",
    component: _7db30b62,
    name: "updatearticle"
  }, {
    path: "/user",
    component: _0dc3e106,
    name: "user"
  }, {
    path: "/",
    component: _68fa06a7,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
